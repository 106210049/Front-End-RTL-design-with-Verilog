`define ARB_IDLE        3'b001
`define ARB_GRANT_TDSP  3'b000
`define ARB_GRANT_DMA   3'b010
`define ARB_CLEAR       3'b011
`define ARB_DMA_PRI     3'b111
